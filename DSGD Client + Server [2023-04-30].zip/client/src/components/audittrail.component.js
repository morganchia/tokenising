import React, { Component } from "react";
import { Navigate } from "react-router-dom";
import AuthService from "../services/auth.service";
import UserOpsRoleDataService from "../services/user_opsrole.service";
import {ExportToExcel} from './Export2Excel'


export default class Settings extends Component {
  constructor(props) {
    super(props);

    this.state = {
      redirect: null,
      userReady: false,
      currentUser: { username: "" },
      _useropsroles : {
        campaign_makers: "",
        campaign_checkers: "",
        campaign_approvers: "",
        mint_makers : "",
        mint_checkers : "",
        mint_approvers : "",
        transfer_makers : "",
        transfer_checkers : "",
        transfer_approvers : "",
        withdraw_makers : "",
        withdraw_checkers : "",
        withdraw_approvers : "",
      },
      data1: null,
      excelfilename: "tokenise_file",
    };
  }

  retrieveAllUserOpsRole() {
    UserOpsRoleDataService.findAll()
      .then(response => {
        console.log("Data received by UserOpsRoleDataService.getAllMakersCheckersApprovers:", response.data);
        
        const campaign_makers = response.data.filter(role => {return role.transactionType.toUpperCase() === "CAMPAIGN" && role.opsroleId === 1});
        const campaign_checkers = response.data.filter(role => {return role.transactionType.toUpperCase() === "CAMPAIGN" && role.opsroleId === 2});
        const campaign_approvers = response.data.filter(role => {return role.transactionType.toUpperCase() === "CAMPAIGN" && role.opsroleId === 3});
        const mint_makers = response.data.filter(role => {return role.transactionType.toUpperCase() === "MINT" && role.opsroleId === 1});
        const mint_checkers = response.data.filter(role => {return role.transactionType.toUpperCase() === "MINT" && role.opsroleId === 2});
        const mint_approvers = response.data.filter(role => {return role.transactionType.toUpperCase() === "MINT" && role.opsroleId === 3});
        const transfer_makers = response.data.filter(role => {return role.transactionType.toUpperCase() === "TRANSFER" && role.opsroleId === 1});
        const transfer_checkers = response.data.filter(role => {return role.transactionType.toUpperCase() === "TRANSFER" && role.opsroleId === 2});
        const transfer_approvers = response.data.filter(role => {return role.transactionType.toUpperCase() === "TRANSFER" && role.opsroleId === 3});
        const withdraw_makers = response.data.filter(role => {return role.transactionType.toUpperCase() === "WITHDRAW" && role.opsroleId === 1});
        const withdraw_checkers = response.data.filter(role => {return role.transactionType.toUpperCase() === "WITHDRAW" && role.opsroleId === 2});
        const withdraw_approvers = response.data.filter(role => {return role.transactionType.toUpperCase() === "WITHDRAW" && role.opsroleId === 3});
        console.log("campaign_makers:", campaign_makers);
        
        this.setState({
          user_opsroles       : response.data,
          _useropsroles : {
            campaign_makers     : campaign_makers,
            campaign_checkers   : campaign_checkers,
            campaign_approvers  : campaign_approvers,
            mint_makers         : mint_makers,
            mint_checkers       : mint_checkers,
            mint_approvers      : mint_approvers,
            transfer_makers     : transfer_makers,
            transfer_checkers   : transfer_checkers,
            transfer_approvers  : transfer_approvers,
            withdraw_makers     : withdraw_makers,
            withdraw_checkers   : withdraw_checkers,
            withdraw_approvers  : withdraw_approvers,
          }
        });
      }
    )
    .catch(e => {
      console.log(e);
      //return(null);
    });  
  }

  componentDidMount() {
    const currentUser = AuthService.getCurrentUser();

    if (!currentUser) this.setState({ redirect: "/login" });
    this.setState({ currentUser: currentUser, userReady: true })

    this.retrieveAllUserOpsRole();
  }

  render() {
    if (this.state.redirect) {
      return <Navigate to={this.state.redirect} />
    }

    const { currentUser, user_opsroles, _useropsroles, data1, excelfilename } = this.state;

    return (
      <div className="container">
        {(this.state.userReady) ?
        <div>
          <header className="jumbotron col-md-8">
            <h3>
              <strong>Audit Trail</strong>
            </h3>
          </header>
        </div>: null}

        <div className="App">
          <ExportToExcel apiData={data1} fileName={excelfilename} />
        </div>
      </div>
    );
  }
}
