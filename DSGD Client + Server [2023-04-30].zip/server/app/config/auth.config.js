module.exports = {
  secret: "BCDA-secret-key"
};
